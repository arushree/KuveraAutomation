package enums;

public enum MobileView {
	NATIVE_APP, WEBVIEW;
}
